from django.urls import path
from .views import index, about, contacts

urlspatterns = [
    path('', index, name='home'),
    path('about', index, name='about'),
    path('contacts', index, name='contacts'),

]