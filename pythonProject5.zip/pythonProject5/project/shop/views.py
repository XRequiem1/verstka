from django.shortcuts import render

products = [
    {'id': 1, 'title': 'skirt', 'size': 'XL', 'price': 2900},
    {'id': 2, 'title': 'skirt', 'size': 'XXL', 'price': 2500},
    {'id': 3, 'title': 'skirt', 'size': 'S', 'price': 2200},
    {'id': 4, 'title': 'skirt', 'size': 'M', 'price': 2100},
    {'id': 5, 'title': 'skirt', 'size': 'L', 'price': 2000},
]

def index(request):
    header = 'Данные'
    langs = ['C', 'C++', 'Python', 'Java', 'JavaScript', 'Pascal']
    user = {'name': 'Vasili', 'surname': 'Pupkin'}
    address = ('Mira', 12, 147)
    data = {'header': header, 'langs': langs, 'user': user, 'address': address}
    return render(request, 'shop/index.html', context=data)

def about(request):
    data = {'name': 'Ann', 'interests': 'programming'}
    return render(request, 'shop/about.html', context=data)

def contacts(request):
    return render(request, 'shop/contacts.html')


